import { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import { saveAs } from "file-saver";
import { Document, Packer, Paragraph } from "docx";
import jsPDF from "jspdf";
import { 
  Send, Loader, Download, Copy, Check, Sparkles, 
  TrendingUp, Brain, FileText, Zap, Shield, Menu, X,
  MessageSquare, History, Settings, PlusCircle
} from "lucide-react";

export default function BlogGenerator() {
  // ========== STATE MANAGEMENT ==========
  const [topic, setTopic] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // SIDEBAR STATE - This is the key!
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // Start closed like ChatGPT
  
  // Chat history (like ChatGPT's left sidebar)
  const [chatHistory, setChatHistory] = useState([
    { id: 1, title: "Welcome to AI Blog Studio", date: "Today" }
  ]);
  
  const chatEndRef = useRef(null);
  const sidebarRef = useRef(null);

  // ========== SIDEBAR BEHAVIOR ==========
  
  // Auto-scroll to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Close sidebar when clicking outside (mobile)
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (window.innerWidth < 768 && isSidebarOpen && 
          sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        setIsSidebarOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isSidebarOpen]);
  
  // Prevent body scroll when sidebar is open on mobile
  useEffect(() => {
    if (isSidebarOpen && window.innerWidth < 768) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isSidebarOpen]);

  // ========== BLOG GENERATION ==========
  const generateBlog = async () => {
    if (!topic.trim()) return;

    setLoading(true);

    // Add user message and empty AI message
    setMessages((prev) => [
      ...prev,
      { role: "user", content: topic, timestamp: new Date(), id: Date.now() },
      { role: "assistant", content: "", timestamp: new Date(), id: Date.now() + 1, isStreaming: true },
    ]);

    // Save to chat history
    const newChat = {
      id: Date.now(),
      title: topic.length > 30 ? topic.substring(0, 30) + "..." : topic,
      date: new Date().toLocaleDateString(),
      messages: messages
    };
    setChatHistory(prev => [newChat, ...prev]);

    try {
      const response = await fetch(`/stream?topic=${encodeURIComponent(topic)}`);

      if (!response.ok) {
        throw new Error("Backend error");
      }

      if (!response.body) {
        throw new Error("No response body");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");

      let result = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        result += chunk;

        setMessages((prev) => {
          const updated = [...prev];
          updated[updated.length - 1] = {
            ...updated[updated.length - 1],
            role: "assistant",
            content: result,
            isStreaming: true,
          };
          return updated;
        });
      }

      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1] = {
          ...updated[updated.length - 1],
          isStreaming: false,
        };
        return updated;
      });
    } catch (error) {
      console.error("Error:", error);

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "⚠️ Error generating content. Please check your connection and try again.",
          timestamp: new Date(),
          id: Date.now(),
          isError: true,
        },
      ]);
    }

    setTopic("");
    setLoading(false);
  };

  // Start new chat (like ChatGPT's "New Chat" button)
  const startNewChat = () => {
    setMessages([]);
    setTopic("");
    setIsSidebarOpen(false); // Close sidebar after starting new chat
  };

  // Load a previous chat
  const loadChat = (chat) => {
    // In a real app, you'd load the actual messages
    // For demo, we'll just set a placeholder
    setMessages([{
      role: "assistant",
      content: `Loading chat: ${chat.title}\n\nThis is a demo. In production, you would load the actual messages from your database.`,
      timestamp: new Date(),
      id: Date.now()
    }]);
    setIsSidebarOpen(false);
  };

  // ========== EXPORT FUNCTIONS ==========
  const downloadPDF = (text) => {
    const pdf = new jsPDF();
    const margin = 20;
    const pageWidth = pdf.internal.pageSize.width - 2 * margin;
    
    pdf.setFontSize(20);
    pdf.text("Blog Post", margin, 20);
    
    pdf.setFontSize(12);
    const lines = pdf.splitTextToSize(text, pageWidth);
    let y = 35;
    
    lines.forEach(line => {
      if (y > pdf.internal.pageSize.height - margin) {
        pdf.addPage();
        y = margin;
      }
      pdf.text(line, margin, y);
      y += 7;
    });
    
    pdf.save(`blog-${Date.now()}.pdf`);
  };

  const downloadDocx = async (text) => {
    const paragraphs = text.split("\n").map((line) => {
      if (line.trim() === "") {
        return new Paragraph({ text: "" });
      }
      return new Paragraph({
        text: line,
        spacing: { after: 120 }
      });
    });
    
    const doc = new Document({
      sections: [{ children: paragraphs }],
    });
    const blob = await Packer.toBlob(doc);
    saveAs(blob, `blog-${Date.now()}.docx`);
  };

  const copyToClipboard = async (text) => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearChat = () => {
    setMessages([]);
  };

  const features = [
    { icon: Sparkles, title: "AI Writing", description: "Advanced AI generates high-quality content" },
    { icon: TrendingUp, title: "SEO Optimization", description: "Built-in SEO best practices" },
    { icon: Brain, title: "Smart Learning", description: "Adapts to your brand voice" },
    { icon: FileText, title: "Export Ready", description: "PDF, DOCX, and copy support" },
  ];

  const suggestions = [
    "AI in Healthcare",
    "Sustainable Living Tips",
    "Future of Remote Work",
    "Digital Marketing Trends"
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-primary-50 to-primary-100">
      {/* ========== NAVBAR - Like ChatGPT's ========== */}
      <nav className="bg-orange/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl px-2 sm:px-2 lg:px-2">
          <div className="flex justify-between items-center h-16">
            {/* Left section with menu button (like ChatGPT) */}
            <div className="flex items-center space-x-3">
              {/* 
                MENU BUTTON - This toggles the sidebar like ChatGPT!
                Clicking this opens/closes the sidebar
              */}
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary-500"
                aria-label={isSidebarOpen ? "Close sidebar" : "Open sidebar"}
              >
                <Menu size={20} className="text-gray-600" />
              </button>

              <div className="text-2xl">✍️</div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-primary-600 to-primary-800 bg-clip-text text-transparent">
                  AI Blog Studio
                </h1>
                <p className="text-xs text-gray-500">Professional Blog Generation</p>
              </div>
            </div>

            {/* Right section */}
            <div className="flex items-center space-x-2">
              {messages.length > 0 && (
                <button
                  onClick={clearChat}
                  className="px-4 py-2 text-gray-600 hover:text-red-600 transition-colors text-sm font-medium"
                >
                  Clear Chat
                </button>
              )}
              <span className="text-xs px-3 py-1 bg-primary-100 text-primary-600 rounded-full font-medium">
                DEMO
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* ========== MAIN CONTENT WITH SIDEBAR ========== */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* 
          SIDEBAR - Like ChatGPT's sidebar
          Slides in from left when menu button is clicked
        */}
        <aside
          ref={sidebarRef}
          className={`
            fixed top-0 left-0 h-full
            w-80 bg-white border-r border-gray-200
            transform transition-transform duration-300 ease-in-out
            z-40 overflow-y-auto
            shadow-xl
            ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          `}
          style={{ top: '64px' }} // Position below navbar
        >
          <div className="p-4">
            {/* New Chat Button - Like ChatGPT's */}
            <button
              onClick={startNewChat}
              className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition-colors mb-6"
            >
              <PlusCircle size={20} />
              <span className="font-medium">New Blog</span>
            </button>

            {/* Chat History - Like ChatGPT's conversation list */}
            <div className="space-y-4">
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-2">
                Recent Chats
              </h3>
              
              <div className="space-y-1">
                {chatHistory.map((chat) => (
                  <button
                    key={chat.id}
                    onClick={() => loadChat(chat)}
                    className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors text-left"
                  >
                    <MessageSquare size={16} className="text-gray-400 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-700 truncate">{chat.title}</p>
                      <p className="text-xs text-gray-400">{chat.date}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Features Section */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-2 mb-3">
                Features
              </h3>
              <div className="space-y-1">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3 px-3 py-2 rounded-lg hover:bg-gray-50">
                    <feature.icon size={16} className="text-primary-500" />
                    <span className="text-sm text-gray-600">{feature.title}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="flex items-center space-x-2 text-xs text-gray-500 px-2">
                <Shield size={12} />
                <span>AI Generated Content</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Overlay for mobile when sidebar is open */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30 transition-opacity duration-300 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
            style={{ top: '64px' }}
          />
        )}

        {/* MAIN CHAT AREA - This expands when sidebar closes */}
        <main className={`
          flex-1 flex flex-col overflow-hidden transition-all duration-300
          ${isSidebarOpen ? 'lg:ml-80' : 'ml-0'}
        `}>
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-4xl mx-auto">
              {messages.length === 0 ? (
                // Empty State
                <div className="flex flex-col items-center justify-center h-full text-center p-8 min-h-[500px]">
                  <div className="w-24 h-24 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                    <span className="text-4xl">✍️</span>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    Start Creating Amazing Content
                  </h3>
                  <p className="text-gray-500 max-w-md mb-6">
                    Enter a topic below and let AI generate a professional, engaging blog post for you.
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {suggestions.map((suggestion) => (
                      <button
                        key={suggestion}
                        onClick={() => setTopic(suggestion)}
                        className="px-3 py-1.5 bg-white border border-gray-200 rounded-full text-sm text-gray-600 hover:border-primary-400 hover:text-primary-600 transition-all"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                // Messages
                <div className="space-y-4">
                  {messages.map((msg, i) => (
                    <div
                      key={msg.id || i}
                      className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div className={`max-w-[85%] md:max-w-[70%] ${msg.role === "user" ? "order-2" : "order-1"}`}>
                        <div className={`flex items-center space-x-2 mb-1 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium ${
                            msg.role === "user" 
                              ? "bg-primary-500 text-white" 
                              : "bg-gray-200 text-gray-600"
                          }`}>
                            {msg.role === "user" ? "U" : "AI"}
                          </div>
                          <span className="text-xs text-gray-400">
                            {msg.timestamp?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <div
                          className={`rounded-2xl px-5 py-3 shadow-sm ${
                            msg.role === "user"
                              ? "bg-primary-500 text-white"
                              : "bg-white border border-gray-200 text-gray-800"
                          } ${msg.isError ? "border-red-200 bg-red-50" : ""}`}
                        >
                          {msg.isStreaming && !msg.content ? (
                            <div className="flex items-center space-x-2">
                              <Loader className="w-4 h-4 animate-spin" />
                              <span>Generating...</span>
                            </div>
                          ) : (
                            <div className="markdown-content">
                              <ReactMarkdown>{msg.content}</ReactMarkdown>
                            </div>
                          )}
                        </div>

                        {msg.role === "assistant" && msg.content && !msg.isStreaming && (
                          <div className="flex items-center space-x-2 mt-2 justify-end">
                            <button
                              onClick={() => copyToClipboard(msg.content)}
                              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-500 hover:text-gray-700"
                            >
                              {copied ? <Check size={14} /> : <Copy size={14} />}
                            </button>
                            <button
                              onClick={() => downloadPDF(msg.content)}
                              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-500 hover:text-gray-700"
                            >
                              <Download size={14} />
                            </button>
                            <button
                              onClick={() => downloadDocx(msg.content)}
                              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-500 hover:text-gray-700"
                            >
                              <Download size={14} />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
              )}
            </div>
          </div>

          {/* Input Area */}
          <div className="border-t border-gray-200 bg-white/50 backdrop-blur-sm p-4">
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                <textarea
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && generateBlog()}
                  placeholder={loading ? "Generating..." : "Enter a topic or ask AI to generate a blog..."}
                  disabled={loading}
                  rows={3}
                  className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none disabled:bg-gray-50"
                />
                <button
                  onClick={generateBlog}
                  disabled={!topic.trim() || loading}
                  className="absolute bottom-3 right-3 p-2 rounded-lg bg-primary-500 text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary-600 transition-colors"
                >
                  {loading ? <Loader size={20} className="animate-spin" /> : <Send size={20} />}
                </button>
              </div>
              <p className="text-xs text-gray-400 mt-2 text-center">
                Press <kbd className="px-1.5 py-0.5 bg-gray-100 rounded text-xs">Enter</kbd> to send
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
