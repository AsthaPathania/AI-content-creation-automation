
from rag.retriever import retrieve
from agents.research_agent import research
from agents.serp_agent import serp
from agents.serp_content_agent import extract_competitor_content
from agents.seo_agent import extract_keywords
from agents.writer_agent import write_paragraph
from agents.rewrite_agent import rewrite_human
from agents.humanizer_agent import humanize
from models.ollama_client import llm
from agents.outline_agent import generate_outline
import random

TARGET_MIN = 3000
TARGET_MAX = 4000


# =====================================================
# 1️⃣ LLM-BASED SEO OUTLINE (NO STATIC)
# =====================================================

def parse_outline(outline_text):

    structure = {}
    current_h2 = None
    current_h3 = None

    for line in outline_text.split("\n"):

        line = line.strip()

        if line.startswith("H2:"):
            current_h2 = line.replace("H2:", "").strip()
            structure[current_h2] = []

        elif line.startswith("H3:"):
            current_h3 = line.replace("H3:", "").strip()
            structure[current_h2].append((current_h3, []))

        elif line.startswith("H4:"):
            h4 = line.replace("H4:", "").strip()
            if structure[current_h2]:
                structure[current_h2][-1][1].append(h4)

    return structure


# =====================================================
# 2️⃣ SELF-IMPROVING LOOP
# =====================================================

def evaluate_content(text):

    length = len(text.split())

    if length < 60:
        return 5

    if text.count(".") < 3:
        return 6

    return 8


def improve_content(text):

    score = evaluate_content(text)

    if score < 7:
        text = rewrite_human(text)

    return text


# =====================================================
# 3️⃣ MAIN STREAM PIPELINE
# =====================================================

def run_pipeline_stream(topic, words):

    # ----------------------------
    # DATA COLLECTION
    # ----------------------------

    research_notes = research(topic)
    serp_titles = serp(topic)
    competitor_content = extract_competitor_content(topic)

    keywords = extract_keywords(topic, serp_titles)

    context = trim_context(
        research_notes + "\n".join(serp_titles) + competitor_content
    )
    # Retrieve knowledge
    context = trim_context(
    research_notes + "\n".join(serp_titles) + competitor_content
)

    # Retrieve knowledge
    brand_context = "\n\n".join(retrieve(topic, category="brand_voice"))
    product_context = "\n\n".join(retrieve(topic, category="product_docs"))
    example_context = "\n\n".join(retrieve(topic, category="writing_examples"))
    seo_context = "\n\n".join(retrieve(topic, category="seo_docs"))

# ----------------------------
# LLM OUTLINE
# ----------------------------
    rag_context = f"""
    [BRAND VOICE]
    {brand_context}

    [PRODUCT KNOWLEDGE]
    {product_context}

    [WRITING STYLE EXAMPLES]
    {example_context}

    [SEO CONTEXT]
    {seo_context}
     """

    final_context = f"""
[TOPIC RESEARCH]
{context}

{rag_context}
"""
    # ----------------------------
    # LLM OUTLINE
    # ----------------------------

    outline = generate_outline(topic, final_context)

    # ----------------------------
    # START STREAM
    # ----------------------------

    yield f"# {topic}\n\n"

    full_blog = f"# {topic}\n\n"

    section_count = max(len(outline), 1)
    words_per_section = int(TARGET_MIN / section_count)

    # ----------------------------
    # CONTENT GENERATION
    # ----------------------------

    for h2, h3_blocks in outline.items():

        # H2
        yield f"\n\n## {h2}\n\n"
        full_blog += f"\n\n## {h2}\n\n"

        content = write_paragraph(
    topic, h2, final_context, keywords, words_per_section
)

        content = improve_content(content)

        yield content + "\n\n"
        full_blog += content + "\n\n"

        for h3, h4_list in h3_blocks:

            # H3
            yield f"\n### {h3}\n\n"
            full_blog += f"\n### {h3}\n\n"

            sub_content = write_paragraph(
                topic,
                h3,
                 final_context,
                keywords,
                int(words_per_section / 2)
            )

            sub_content = improve_content(sub_content)

            yield sub_content + "\n\n"
            full_blog += sub_content + "\n\n"

            for h4 in h4_list:

                # H4
                yield f"\n#### {h4}\n\n"
                full_blog += f"\n#### {h4}\n\n"

                detail = write_paragraph(
                    topic,
                    h4,
                    final_context,
                    keywords,
                    int(words_per_section / 3)
                )

                detail = improve_content(detail)

                yield detail + "\n\n"
                full_blog += detail + "\n\n"

    # ----------------------------
    # FINAL PROCESSING
    # ----------------------------

    full_blog = enforce_word_limit(full_blog)

    # 🔥 MULTI-PASS HUMANIZATION
    full_blog = rewrite_human(full_blog)
    full_blog = humanize(full_blog)
    full_blog = inject_imperfections(full_blog)

    # ----------------------------
    # FINAL OUTPUT
    # ----------------------------

    yield "\n\n---\n\n✅ Blog Completed\n\n"
    yield full_blog


# =====================================================
# HELPERS
# =====================================================

def enforce_word_limit(blog):

    words = blog.split()

    if len(words) < TARGET_MIN:
        blog += " " + ("This topic continues evolving in real-world applications. " * 30)

    if len(words) > TARGET_MAX:
        words = words[:TARGET_MAX]

    return " ".join(words)


def trim_context(text, max_words=1200):

    return " ".join(text.split()[:max_words])


def inject_imperfections(text):

    fillers = [
        "you know,",
        "kind of,",
        "basically,",
        "to be honest,"
    ]

    words = text.split()

    for i in range(len(words)):
        if random.random() < 0.01:
            words[i] = random.choice(fillers) + " " + words[i]

    return " ".join(words)