import textstat


def seo_score(blog, keyword):

    readability = textstat.flesch_reading_ease(blog)

    keyword_count = blog.lower().count(keyword.lower())

    score = 0

    if readability > 50:
        score += 40

    if keyword_count > 5:
        score += 30

    if len(blog.split()) > 2000:
        score += 30

    return score