import stripe
from config import STRIPE_SECRET

stripe.api_key = STRIPE_SECRET


def create_checkout_session():

    session = stripe.checkout.Session.create(

        payment_method_types=["card"],

        mode="subscription",

        line_items=[
            {
                "price": "price_id_here",
                "quantity": 1
            }
        ]
    )

    return session.url