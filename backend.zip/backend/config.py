DATABASE_URL = "postgresql://postgres:password@localhost/ai_content"

REDIS_URL = "redis://localhost:6379"

OLLAMA_URL = "http://localhost:11434/api/generate"

STRIPE_SECRET = "your_stripe_secret_key"