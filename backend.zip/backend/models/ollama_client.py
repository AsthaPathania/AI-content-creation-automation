import requests

OLLAMA_URL = "http://localhost:11434/api/generate"


def llm(prompt):

    payload = {
        "model": "phi3",
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.8,
            "top_p": 0.9
        }
    }

    r = requests.post(OLLAMA_URL, json=payload)

    try:
        return r.json()["response"]
    except:
        return ""