from fastapi import APIRouter
from jwt_handler import create_token

router = APIRouter()


@router.post("/login")
def login():

    token = create_token("user1")

    return {"token": token}