from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pipeline import run_pipeline_stream

app = FastAPI()


@app.get("/")
def root():
    return {"status": "API running"}


@app.get("/stream")
def stream_blog(topic: str, words: int = 3000):

    def generator():
        for chunk in run_pipeline_stream(topic, words):
            yield chunk

    return StreamingResponse(generator(), media_type="text/plain")