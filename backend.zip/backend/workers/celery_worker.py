from celery import Celery
from config import REDIS_URL

celery = Celery(
    "worker",
    broker=REDIS_URL
)


@celery.task
def generate_blog_task(topic):

    from pipeline import run_pipeline

    return run_pipeline(topic, 3500)