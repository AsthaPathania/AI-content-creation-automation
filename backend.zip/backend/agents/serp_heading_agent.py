import requests
from bs4 import BeautifulSoup


def extract_serp_headings(topic):

    search_url = f"https://www.google.com/search?q={topic}"

    headers = {"User-Agent": "Mozilla/5.0"}

    r = requests.get(search_url, headers=headers)

    soup = BeautifulSoup(r.text, "html.parser")

    links = []

    for a in soup.select("a"):

        href = a.get("href")

        if href and "http" in href and "google" not in href:
            links.append(href)

    headings = []

    for link in links[:5]:

        try:

            page = requests.get(link, headers=headers, timeout=5)

            s = BeautifulSoup(page.text, "html.parser")

            for tag in s.find_all(["h1", "h2", "h3"]):

                text = tag.get_text().strip()

                if len(text) > 10:
                    headings.append(text)

        except:
            continue

    return list(set(headings))[:20]