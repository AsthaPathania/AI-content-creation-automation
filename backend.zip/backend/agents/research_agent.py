from models.ollama_client import llm


def research(topic):

    prompt = f"""
OPIC:{topic}

GOAL

Act as an investigative researcher and senior SEO strategist.

1. Produce an evidence-based research dossier that can be turned into a definitive, SEO-optimized blog post on the topic above.
2. Pull insights from a diverse mix of sources to ensure depth, originality, and topical authority.

SCOPE OF SOURCES

A. Top-ranking Google pages (organic results page 1–2).

B. Authoritative industry publications & scholarly / peer-reviewed articles (Google Scholar, PubMed, arXiv, SSRN, etc.).

C. Crowd-sourced knowledge & user sentiment: LinkedIn posts, Reddit threads, Quora answers, specialist forums.

D. Rich-media: YouTube videos, podcasts, webinars (quote speaker statements with timestamps).

E. Expert commentary: quotes from recognised subject-matter experts (cite name, role, source URL).

RESEARCH TASKS & OUTPUT STRUCTURE

Return your findings in **markdown** with the following sections:

1. Executive Summary
    
    • 100–150-word snapshot of the most important takeaways.
    
2. Search Intent & SERP Landscape
    
    • Primary search intent (informational / commercial / etc.).
    
    • Notable content types dominating the SERP (guides, tool pages, videos, etc.).
    
    • Common on-page elements (word count range, schema, FAQs, visuals).
    
3. Key Sub-Topics & Questions (People Also Ask style)
    
    • Bullet list of 8–12 high-value sub-topics / questions the post must satisfy.
    
4. Source-Backed Insights (core of the dossier)
    
    For each sub-topic:
    
    • Concise explanation (2–4 sentences).
    
    • Supporting data / stat (cite source).
    
    • Relevant expert quote or user quote (≤40 words, cite).
    
    • Link(s) to 1–2 reference pages.
    
    • Opportunity angle (how we can add unique value or better answer).
    
5. Original Angle Recommendations
    
    • 3–5 specific perspectives, examples, or data visualisations that are *not* present in most competing pages.
    
6. SEO Assets
    
    • Primary keyword + 5–7 secondary keywords (include long-tails).
    
    • Suggested H1, H2, H3 outline (markdown list).
    
    • Schema ideas (FAQ, How-To, Video, etc.).
    
    • Internal-link opportunities (note generic anchor text like “guide”, “calculator” if site pages aren’t provided).
    
7. Content Enrichment Ideas
    
    • Embeddable media suggestions (charts, comparison tables, code snippets, short demo video, etc.).
    
    • Potential interview targets (names & contact channel if available).
    
    • 2–3 downloadable asset ideas (checklist, template, calculator).
    
8. Source Appendix
    
    • Full list of all URLs used, grouped by type (Top-ranking, Scholarly, Social, Video, Expert).
    

RESEARCH GUIDELINES

• Cite every fact, quote, or statistic with an inline markdown link “(Source)”.

• Favour recent (<24 months) sources where possible; flag anything older.

• If scholarly material is pay-walled, summarise the abstract and cite.

• Quote social/user content verbatim but trim profanity and add “[…]” for brevity.

• For YouTube, include “[timestamp]” after the quote and link to that time.

• Avoid speculation; base recommendations on evidence gathered.

• Write in clear, professional English suitable for an experienced but non-technical reader.

DELIVERABLE

Respond with the markdown dossier only—no extra commentary outside the defined sections.
"""

    return llm(prompt)