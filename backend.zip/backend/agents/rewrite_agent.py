from models.ollama_client import llm


def rewrite_human(text):

    prompt = f"""
Rewrite the following content to sound more human.

Instructions:
- make tone conversational
- vary sentence structure
- reduce AI-like patterns
- keep meaning same
- avoid repetition

Content:
{text}
"""

    return llm(prompt)