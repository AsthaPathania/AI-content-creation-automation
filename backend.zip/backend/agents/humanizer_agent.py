import random
import re


# ============================
# MAIN HUMANIZER FUNCTION
# ============================

def humanize(text):

    paragraphs = split_paragraphs(text)

    paragraphs = vary_paragraph_structure(paragraphs)

    paragraphs = rewrite_sentences(paragraphs)

    paragraphs = inject_human_tone(paragraphs)

    paragraphs = vary_sentence_length(paragraphs)

    text = "\n\n".join(paragraphs)

    text = cleanup(text)

    return text


# ============================
# SPLIT PARAGRAPHS
# ============================

def split_paragraphs(text):

    return [p.strip() for p in text.split("\n") if p.strip()]


# ============================
# PARAGRAPH STRUCTURE VARIATION
# ============================

def vary_paragraph_structure(paragraphs):

    new = []

    for p in paragraphs:

        # Merge small paragraphs
        if len(p.split()) < 40 and random.random() < 0.3 and len(new) > 0:
            new[-1] += " " + p

        # Split large paragraphs
        elif len(p.split()) > 120 and random.random() < 0.4:
            words = p.split()
            mid = len(words) // 2

            new.append(" ".join(words[:mid]))
            new.append(" ".join(words[mid:]))

        else:
            new.append(p)

    return new


# ============================
# SENTENCE REWRITING
# ============================

def rewrite_sentences(paragraphs):

    new_paragraphs = []

    for p in paragraphs:

        sentences = re.split(r'(?<=[.!?]) +', p)

        new_sentences = []

        for s in sentences:

            if random.random() < 0.35:
                s = restructure_sentence(s)

            if random.random() < 0.25:
                s = replace_transitions(s)

            new_sentences.append(s)

        new_paragraphs.append(" ".join(new_sentences))

    return new_paragraphs


# -----------------------------

def restructure_sentence(s):

    if "," in s and random.random() < 0.5:
        parts = s.split(",", 1)

        if len(parts) > 1:
            s = parts[1].strip().capitalize() + ". " + parts[0]

    return s


# -----------------------------

def replace_transitions(s):

    replacements = {
        "However": ["But", "Still", "That said"],
        "Therefore": ["So", "Because of this", "As a result"],
        "Furthermore": ["Also", "On top of that"],
        "Moreover": ["Plus", "Another thing is"],
    }

    for key, values in replacements.items():

        if key in s:
            s = s.replace(key, random.choice(values))

    return s


# ============================
# HUMAN TONE INJECTION
# ============================

def inject_human_tone(paragraphs):

    phrases = [
        "Honestly,",
        "If you think about it,",
        "In real life,",
        "From a practical point of view,",
        "Interestingly,",
        "You might notice,"
    ]

    new = []

    for p in paragraphs:

        if random.random() < 0.25:
            p = random.choice(phrases) + " " + p.lower()

        new.append(p)

    return new


# ============================
# SENTENCE LENGTH VARIATION
# ============================

def vary_sentence_length(paragraphs):

    new_paragraphs = []

    for p in paragraphs:

        sentences = re.split(r'(?<=[.!?]) +', p)

        new_sentences = []

        for s in sentences:

            words = s.split()

            # Break long sentences
            if len(words) > 25 and random.random() < 0.4:

                mid = len(words) // 2

                part1 = " ".join(words[:mid]) + "."
                part2 = " ".join(words[mid:])

                new_sentences.append(part1)
                new_sentences.append(part2)

            else:
                new_sentences.append(s)

        new_paragraphs.append(" ".join(new_sentences))

    return new_paragraphs


# ============================
# CLEANUP
# ============================

def cleanup(text):

    text = re.sub(r'\s+', ' ', text)

    text = text.replace("..", ".")

    return text.strip()