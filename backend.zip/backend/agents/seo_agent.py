def extract_keywords(topic, titles):

    keywords = []

    for title in titles:

        for word in title.lower().split():

            if len(word) > 4 and word not in keywords:
                keywords.append(word)

    keywords.append(topic)

    return keywords[:15]