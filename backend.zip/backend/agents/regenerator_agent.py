from models.ollama_client import llm


def regenerate(blog, feedback):

    prompt = f"""
Improve the blog using this feedback.

Feedback:
{feedback}

Blog:
{blog}
"""

    return llm(prompt)