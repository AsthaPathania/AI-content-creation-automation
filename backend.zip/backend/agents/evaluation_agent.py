from models.ollama_client import llm


def evaluate_content(text):

    prompt = f"""
Evaluate this blog content.

Score (0–10) for:
- human-like writing
- SEO quality
- readability

Return JSON:
{{
  "score": number,
  "issues": ["issue1", "issue2"]
}}
Content:
{text}
"""

    import json
    try:
        return json.loads(llm(prompt))
    except:
        return {"score": 5, "issues": ["Unknown"]}