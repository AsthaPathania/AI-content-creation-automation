import requests
from bs4 import BeautifulSoup


def extract_competitor_content(topic):

    search_url = f"https://www.google.com/search?q={topic}"

    headers = {"User-Agent": "Mozilla/5.0"}

    r = requests.get(search_url, headers=headers)

    soup = BeautifulSoup(r.text, "html.parser")

    links = []

    for a in soup.select("a"):

        href = a.get("href")

        if href and "http" in href and "google" not in href:
            links.append(href)

    articles = []

    for link in links[:5]:

        try:

            page = requests.get(link, headers=headers, timeout=5)

            s = BeautifulSoup(page.text, "html.parser")

            paragraphs = [p.text for p in s.select("p")]

            articles.append(" ".join(paragraphs[:15]))

        except:
            continue

    return "\n".join(articles)