import requests
from bs4 import BeautifulSoup


def serp(topic):

    url = f"https://www.google.com/search?q={topic}"

    headers = {"User-Agent": "Mozilla/5.0"}

    r = requests.get(url, headers=headers)

    soup = BeautifulSoup(r.text, "html.parser")

    titles = []

    for h in soup.select("h3"):
        titles.append(h.get_text())

    return titles[:10]