from models.ollama_client import llm


def repurpose(blog):

    linkedin = llm("Rewrite this blog as LinkedIn post\n" + blog)

    twitter = llm("Rewrite this blog as Twitter thread\n" + blog)

    email = llm("Rewrite this blog as newsletter\n" + blog)

    return linkedin, twitter, email