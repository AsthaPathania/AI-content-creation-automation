from models.ollama_client import llm
import json


def generate_outline(topic, context):

    prompt = f"""
You are an expert SEO content strategist.

Task:
Generate a dynamic, high-quality blog outline for the given topic.

Topic: {topic}

Use the following context while generating the outline:
{context}

Instructions:
- First infer what type of blog this should be based on the topic
  (examples: informational, tutorial, comparison, listicle, problem-solution, product-led, thought leadership)
- Choose the most natural and useful structure for that topic
- Do NOT force the same structure for every topic
- Make the outline SEO-friendly and realistic
- Reflect company/product relevance where useful
- Avoid generic AI-style headings

Requirements:
- Return 5 to 8 H2 sections
- Each H2 should have 2 to 3 H3 subsections
- The structure should feel like a real published blog
- If the topic is tutorial-based, use step-by-step style
- If the topic is comparison-based, use comparison structure
- If the topic is informational, use explanatory structure
- If the topic is product/service related, include practical application or use-case sections where relevant

Return ONLY valid JSON in this exact format:
{{
  "H2 Section Title": ["H3 Subsection 1", "H3 Subsection 2"]
}}
"""

    response = llm(prompt)

    try:
        return json.loads(response)
    except:
        return fallback_outline(topic)


def fallback_outline(topic):
    return {
        "Introduction": ["Overview", "Why it matters"],
        f"Understanding {topic}": ["Definition", "Core concepts"],
        "Key Applications": ["Use cases", "Practical value"],
        "Common Challenges": ["Pain points", "Things to consider"],
        "Best Practices": ["Recommendations", "Implementation tips"],
        "Conclusion": ["Summary", "Final thoughts"]
    }