from models.ollama_client import llm


def improve_content(text, issues):

    prompt = f"""
Improve this blog content.

Fix:
{issues}

Make it:
- more human
- conversational
- less robotic
- varied sentence structure

Content:
{text}
"""

    return llm(prompt)