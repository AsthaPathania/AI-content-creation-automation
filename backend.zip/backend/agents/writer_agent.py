from models.ollama_client import llm


def write_paragraph(topic, section, context, keywords, words):

    keyword_string = ", ".join(keywords)

    prompt = f"""
You are writing a high-quality company blog section.

Task:
Write a natural, useful, human-sounding paragraph for the given blog section.

Topic: {topic}
Section: {section}

Use the following context while writing:
{context}

SEO Keywords:
{keyword_string}

Writing goals:
- sound natural and human, not robotic
- reflect company tone and writing style where possible
- use practical explanations, not vague filler
- include examples, comparisons, or observations where useful
- make the paragraph feel like part of a real published blog

Style:
- mix short and medium-length sentences
- slightly conversational but professional
- clear and informative
- avoid repetitive AI phrasing
- avoid overly polished or unnatural transitions
- avoid generic opening lines like "In today's world"

Rules:
- around {words} words
- DO NOT write headings
- DO NOT use bullet points
- DO NOT repeat the section title unnecessarily
- keep it readable and realistic
"""

    text = llm(prompt)

    return text.replace("#", "").strip()