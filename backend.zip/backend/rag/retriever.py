# from sentence_transformers import SentenceTransformer
# import chromadb

# model = SentenceTransformer("all-MiniLM-L6-v2")
# client = chromadb.Client()
# collection = client.get_collection(name="knowledge")

# def retrieve(query, top_k=5, category=None):
#     query_embedding = model.encode(query).tolist()

#     results = collection.query(
#         query_embeddings=[query_embedding],
#         n_results=top_k
#     )

#     docs = results["documents"][0]
#     metadata = results["metadatas"][0]

#     # Optional filtering by category
#     if category:
#         filtered = [
#             d for d, m in zip(docs, metadata)
#             if m["category"] == category
#         ]
#         return filtered

#     return docs





import os
from sentence_transformers import SentenceTransformer
import chromadb

# ----------------------------
# Setup paths
# ----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))   # backend/rag
DB_PATH = os.path.join(BASE_DIR, "chroma_db")

# ----------------------------
# Initialize model + persistent Chroma client
# ----------------------------
model = SentenceTransformer("all-MiniLM-L6-v2")
client = chromadb.PersistentClient(path=DB_PATH)

# ----------------------------
# Safely load collection
# ----------------------------
try:
    collection = client.get_collection(name="knowledge")
except Exception:
    collection = client.get_or_create_collection(name="knowledge")


def retrieve(query, top_k=5, category=None):
    # If collection is empty, return empty list safely
    try:
        count = collection.count()
    except:
        return []

    if count == 0:
        return []

    query_embedding = model.encode(query).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=min(top_k, count)
    )

    docs = results.get("documents", [[]])[0]
    metadata = results.get("metadatas", [[]])[0]

    # Optional filtering by category
    if category:
        filtered = [
            d for d, m in zip(docs, metadata)
            if m.get("category") == category
        ]
        return filtered

    return docs
