from sklearn.feature_extraction.text import TfidfVectorizer

vectorizer = TfidfVectorizer()


def embed(texts):

    return vectorizer.fit_transform(texts)