from sklearn.metrics.pairwise import cosine_similarity
from rag.embeddings import embed


documents = []


def add_document(text):
    documents.append(text)


def search(query):

    if not documents:
        return ""

    matrix = embed(documents + [query])

    sims = cosine_similarity(matrix[-1], matrix[:-1])

    best_index = sims.argmax()

    return documents[best_index]