import os
from sentence_transformers import SentenceTransformer
import chromadb

# ----------------------------
# Setup paths
# ----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))   # backend/rag
PROJECT_BACKEND_DIR = os.path.dirname(BASE_DIR)         # backend
KNOWLEDGE_DIR = os.path.join(PROJECT_BACKEND_DIR, "Knowledge")
DB_PATH = os.path.join(BASE_DIR, "chroma_db")

# ----------------------------
# Initialize model + persistent Chroma client
# ----------------------------
model = SentenceTransformer("all-MiniLM-L6-v2")
client = chromadb.PersistentClient(path=DB_PATH)
collection = client.get_or_create_collection(name="knowledge")


def load_documents():
    docs = []

    if not os.path.exists(KNOWLEDGE_DIR):
        print(f"❌ Knowledge folder not found: {KNOWLEDGE_DIR}")
        return docs

    for root, _, files in os.walk(KNOWLEDGE_DIR):
        for file in files:
            if file.endswith(".txt"):
                path = os.path.join(root, file)

                try:
                    with open(path, "r", encoding="utf-8") as f:
                        text = f.read().strip()

                    if not text:
                        continue

                    docs.append({
                        "text": text,
                        "source": file,
                        "category": os.path.basename(root),
                        "full_path": path
                    })

                except Exception as e:
                    print(f"⚠️ Error reading {path}: {e}")

    return docs


def ingest():
    docs = load_documents()

    if not docs:
        print("⚠️ No documents found to ingest.")
        return

    print(f"📄 Found {len(docs)} documents. Ingesting into ChromaDB...")

    # Optional: clear old collection data to avoid duplicates
    try:
        client.delete_collection(name="knowledge")
    except:
        pass

    new_collection = client.get_or_create_collection(name="knowledge")

    for i, doc in enumerate(docs):
        try:
            embedding = model.encode(doc["text"]).tolist()

            new_collection.add(
                documents=[doc["text"]],
                embeddings=[embedding],
                metadatas=[{
                    "source": doc["source"],
                    "category": doc["category"],
                    "path": doc["full_path"]
                }],
                ids=[str(i)]
            )

            print(f"✅ Ingested: {doc['source']} ({doc['category']})")

        except Exception as e:
            print(f"⚠️ Failed to ingest {doc['source']}: {e}")

    print("\n🎉 Knowledge ingestion complete.")
    print(f"📁 Chroma DB stored at: {DB_PATH}")


if __name__ == "__main__":
    ingest()